document.getElementById('collectBtn').addEventListener('click', async () => {
    try {
        const tabs = await chrome.tabs.query({ currentWindow: true });
        let fullContext = "--- МОЙ КОНТЕКТ ДЛЯ AI ---\n\n";

        for (const tab of tabs) {
            // Собираем текст только с реальных сайтов (http/https)
            if (tab.url && tab.url.startsWith('http')) {
                try {
                    const [injection] = await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            // Берем только видимый текст и обрезаем лишние пробелы
                            return document.body.innerText.substring(0, 3000).trim();
                        }
                    });

                    if (injection && injection.result && injection.result.length > 10) {
                        fullContext += `📄 ИСТОЧНИК: ${tab.title}\n🔗 URL: ${tab.url}\n\n${injection.result}\n\n====================\n\n`;
                    }
                } catch (e) {
                    console.log("Пропустил вкладку:", tab.title);
                }
            }
        }

        if (fullContext.length < 50) {
            alert('Текст не найден. Открой хотя бы один сайт!');
        } else {
            await navigator.clipboard.writeText(fullContext);
            alert('Успех! Весь контекст в буфере обмена.');
        }
        
    } catch (error) {
        alert('Ошибка доступа к вкладкам');
    }
});
