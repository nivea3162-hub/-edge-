// Простые правила для поиска почты и API ключей
const sensitivePatterns = {
    email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
    apiKey: /(sk-[a-zA-Z0-9]{32,}|AIza[a-zA-Z0-9_-]{35})/g // Примеры для OpenAI и Google
};

document.addEventListener('copy', (e) => {
    let selection = document.getSelection().toString();
    
    if (selection) {
        let cleanedText = selection
            .replace(sensitivePatterns.email, "[PROTECTED_EMAIL]")
            .replace(sensitivePatterns.apiKey, "[PROTECTED_API_KEY]");
        
        // Если текст изменился, подменяем буфер обмена
        if (cleanedText !== selection) {
            e.clipboardData.setData('text/plain', cleanedText);
            e.preventDefault();
            console.log("AI Shield: Данные защищены перед копированием!");
        }
    }
});
